$("#deposit").addClass('active');

$(document).on("keydown", "form", function(event) { 
    return event.key != "Enter";
});

$(document).ready(function() {
  let maximumFractionDigits = 0;
  var valueInput = $("#deposit-amount");

  const formatNumber = (value) => {
    const parsedValue = value.replace(/[^\d,]/gi, '').replace(/(?<!^[\d-]+)\./g, '');
    return parsedValue ? (+parsedValue).toLocaleString('in-ID', {
      maximumFractionDigits
    }) : '';
  }

  valueInput.on('input', function() {
    if (!this.value || (maximumFractionDigits && this.value.endsWith('.'))) {
      return
    }
    $(this).val(formatNumber(this.value));
  });
});

$( "#deposit-amount" ).keyup(function( event ) {
            const str = this.value;
            const number = parseFloat(str.replaceAll(".", ""));
            var x = document.getElementById('amount');
            x.value = number;
            b = x.value = number;
            
            if (b < 999) {
                $('#warning-depo').html('Minimal Deposit Saldo adalah Rp 1.000');
                $('#button-submit').css("display", "none");
            } else if (b > 2000000){
                $('#warning-depo').html('Maximal Deposit adalah Rp2.000.000');
                $('#button-submit').css("display", "none");
            } else if (b > 999) {
                $('#warning-depo').html('');
                $('#button-submit').css("display", "block");
            }
})
