$("#order-history").addClass('active');

            $(document).ready(function(){

                $('#txt_searchall').keyup(function(){
                    var search = $(this).val();

                    $('table tbody tr').hide();

                    var len = $('table tbody tr:not(.notfound) td:contains("'+search+'")').length;

                    if(len > 0){
                      $('table tbody td:contains("'+search+'")').each(function(){
                          $(this).closest('tr').show();
                      });
                    }else{
                      $('.notfound').show();
                    }
                    
                });

                $('#txt_name').keyup(function(){
                    var search = $(this).val();

                    $('table tbody tr').hide();

                    var len = $('table tbody tr:not(.notfound) td:nth-child(2):contains("'+search+'")').length;
                    
                    if(len > 0){
                      $('table tbody tr:not(.notfound) td:contains("'+search+'")').each(function(){
                          $(this).closest('tr').show();
                      });
                    }else{
                      $('.notfound').show();
                    }
                    
                });
               
            });

            $.expr[":"].contains = $.expr.createPseudo(function(arg) {
                return function( elem ) {
                    return $(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
                };
            });
            
            var copyNum = new Audio('/assets/audio/button.mp3')
            function copyToClipboard(element, newText = '') {
              let text = '';
              if (newText != '') {
                text = $(element).html()
                $(element).html($(element).html() + newText)
              }
              copyNum.play();
              var $temp = $("<textarea>");
              var brRegex = /<br\s*[\/]?>/gi;
              $("body").append($temp);
              $temp.val($(element).html().replace(brRegex, "\r\n")).select();
              document.execCommand("copy");
              $temp.remove();
              if (newText != '') {
                $(element).html(text)
              }
              $.toast({
                text: "Nomor Berhasil disalin!",
                showHideTransition: "slide",
                icon: "info",
                position: "top-left",
                hideAfter: "2000"
            })
          }
var acc = document.getElementsByClassName("accordion");
var i;
for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}