$(document).ready(function() {
    $('#saldo-user').load('/action/show/user/saldo');
    $("#menu-swipe").click(function() {
        $("#menu").removeClass('hide') && $("#menu").addClass('show') && $("#body").addClass('overflow');
        $("#focus-menu").addClass('active-focus');
    })
    $("#menu-close").click(function() {
        $("#menu").removeClass('show');
        $("#focus-menu").removeClass('active-focus');
        $("#body").removeClass('overflow');
    })
    $("#focus-menu").click(function() {
        $("#menu").removeClass('show') && $("#menu").addClass('hide');
        $("#focus-menu").removeClass('active-focus');
        $("#body").removeClass('overflow');
    })
    $("#username").click(function() {
        window.open('/user', '_self');
    });
    $("#wallet-container").click(function() {
        window.open('/deposit', '_self');
    })
    $("#wadmin").click( function() {
        window.location.assign("https://wa.wizard.id/11c00e")
    });
})