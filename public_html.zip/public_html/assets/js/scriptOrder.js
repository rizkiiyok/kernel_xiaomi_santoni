function clearAll(windowObject) {
  var id = Math.max(
    windowObject.setInterval(noop, 1000),
  );

  while (id--) {
    windowObject.clearInterval(id);
  }

  function noop(){}
}

function NotifyT() {
    if(window.location.href.indexOf("#succes-order") > -1) {
         alert("your url contains the name franky");
    }
}

$(document).ready(function() {
    $(".select-select2").select2({ });
    $("#order").addClass('active');
    $('#list-order').load('/action/show/order/list');
})

var copyNum = new Audio('/assets/audio/button.mp3')
		function copyToClipboard(element, newText = '') {
			let text = '';
			if (newText != '') {
				text = $(element).html()
				$(element).html($(element).html() + newText)
			}
			copyNum.play();
			var $temp = $("<textarea>");
			var brRegex = /<br\s*[\/]?>/gi;
			$("body").append($temp);
			$temp.val($(element).html().replace(brRegex, "\r\n")).select();
			document.execCommand("copy");
			$temp.remove();
			if (newText != '') {
				$(element).html(text)
			}
      $.toast({
        text: "Nomor Berhasil disalin!",
        showHideTransition: "slide",
        icon: "info",
        position: "top-left",
        hideAfter: "2000"
    })
	}

$('#btn-order').click(function () {
    $('#btn-order').css('display','none');
    $('#check-order').prepend('<svg id="waiting-check" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: none; display: block; shape-rendering: auto;" width="60px" height="60px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid"><path fill="#442dff" d="M73,50c0-12.7-10.3-23-23-23S27,37.3,27,50 M30.9,50c0-10.5,8.5-19.1,19.1-19.1S69.1,39.5,69.1,50"><animateTransform attributeName="transform" attributeType="XML" type="rotate" dur="1s" from="0 50 50" to="360 50 50" repeatCount="indefinite" /></path></svg>');
    setTimeout( function() {
    var value = $('#order-name').val();
    var Url = "/action/create/order/aplikasi";
    $.ajax({
        type: "POST",
        url: Url,
        data: {aplikasi: value},
        success: function (response) {
                if (response == 1) {
                        $('#waiting-check').remove();
                        $('#btn-order').css('display','block');
                        console.clear();
                        clearAll(window);
                        $('#list-order').load('/action/show/order/list');
                        $('#saldo-user').load('/action/show/user/saldo');
                        $.toast({
                            text: 'Order Berhasil Ditambahkan',
                            showHideTransition: 'slide',
                            icon: 'info',
                            position: 'top-left',
                            hideAfter: '3000'
                        })
                } else if (response == 2) {
                        $('#waiting-check').remove();
                        $('#btn-order').css('display','block');
                        $.toast({
                            text: 'Maximal 2 Order Berlangsung',
                            showHideTransition: 'slide',
                            icon: 'info',
                            position: 'top-left',
                            hideAfter: '3000'
                        })
                } else if (response == 3) {
                        $('#waiting-check').remove();
                        $('#btn-order').css('display','block');
                        $.toast({
                            text: 'Server Kami sedang padat, Silahkan order kembali beberapa saat lagi !!',
                            showHideTransition: 'slide',
                            icon: 'info',
                            position: 'top-left',
                            hideAfter: '3000'
                        })
                } else if (response == 4) {
                        $('#waiting-check').remove();
                        $('#btn-order').css('display','block');
                        $.toast({
                            text: 'Stock Aplikasi sedang kosong, Mohon tunggu kami akan mengisinya !!',
                            showHideTransition: 'slide',
                            icon: 'info',
                            position: 'top-left',
                            hideAfter: '3000'
                        })
                } else if (response == 5) {
                        $('#waiting-check').remove();
                        $('#btn-order').css('display','block');
                        $.toast({
                            text: 'Saldo anda Tidak Mencukupi, Silahkan isi ulang saldo !!',
                            showHideTransition: 'slide',
                            icon: 'info',
                            position: 'top-left',
                            hideAfter: '3000'
                        })
                } else if (response == 6) {
                        $('#waiting-check').remove();
                        $('#btn-order').css('display','block');
                        $.toast({
                            text: 'Masukkan Aplikasi yang valid !!',
                            showHideTransition: 'slide',
                            icon: 'info',
                            position: 'top-left',
                            hideAfter: '3000'
                        })
                }
            }
    });
    }, 500);
})