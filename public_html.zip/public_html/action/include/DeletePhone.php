<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');
if (empty($_SESSION['admin_active'])) { header("Location: /"); }

$args = array('phoneId' => $_GET['phoneId']);

$result = $mysql->query("SELECT * FROM stocknomor WHERE phone='$args[phoneId]' and status_order='kosong'");
if ($rows = mysqli_fetch_array($result)) {
    mysqli_query($mysql, "UPDATE stocknomor SET nomor='', status_order='', app_use='', user_order='', nama_aplikasi='' WHERE phone='$rows[phone]' and status_order='kosong'");
    header("Location: /iyok/stocknomor");
}
?>