<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');

$auth = array(
    'username' => $_SESSION['username'],
    'email' => $_SESSION['email'],
);

$result = $mysql->query("SELECT saldo_user FROM rsusers12 WHERE username='$auth[username]' and email='$auth[email]'");

if ($rows = mysqli_fetch_assoc($result)) {
    echo '&nbsp;&nbsp;Rp'.number_format($rows['saldo_user'],0,',','.');
}
?>