<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');

$db = $mysql;
$args = array(
    'username' => $_SESSION['username'],
    'depoId' => $_GET['cancelDepoId']
);
$result = $db->query("SELECT * FROM depo WHERE username='$args[username]' and id='$args[depoId]' LIMIT 1");

if ($rows = mysqli_fetch_array($result)) {
    mysqli_query($mysql, "DELETE FROM depo WHERE username='$args[username]' and id='$args[depoId]' and status='UNPAID' LIMIT 1");
    $_SESSION['cancelDeposit'] = array('time' => time());
    header("Location: /deposit");
}
?>