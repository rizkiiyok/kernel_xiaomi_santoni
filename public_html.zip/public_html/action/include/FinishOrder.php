<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');

$db = $mysql;
$args = array(
    'username' => $_SESSION['username'],
    'orderId' => $_GET['finishId']
);
$result = $db->query("SELECT * FROM turtor WHERE user_order='$args[username]' and status_order='terselesaikan' and id='$args[orderId]' LIMIT 1");

if ($rows = mysqli_fetch_array($result)) {
    mysqli_query($mysql, "DELETE FROM turtor WHERE id='$args[orderId]' and user_order='$args[username]'");
    echo 1;
} else {
    echo 0;
}
?>