<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');

$db = $mysql;
$args = array(
    'username' => $_SESSION['username'],
    'orderId' => $_GET['resendId']
);
$result = $db->query("SELECT * FROM turtor WHERE user_order='$args[username]' and status_order='terselesaikan' and id='$args[orderId]' LIMIT 1");

if ($rows = mysqli_fetch_array($result)) {
    mysqli_query($db, "UPDATE turtor SET refresh='0' WHERE user_order='$args[username]' and status_order='terselesaikan' and id='$args[orderId]' LIMIT 1");
    echo 1;
} else {
    echo 0;
}
?>