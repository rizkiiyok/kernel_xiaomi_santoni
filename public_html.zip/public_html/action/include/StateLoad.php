<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');
if (empty($_SESSION['admin_active'])) { header("Location: /"); }

date_default_timezone_set("Asia/Jakarta");
$WaktuSekarang = date('YmdHi');

$result = $mysql->query("SELECT * FROM turtor WHERE status_order='terselesaikan' ORDER BY id ASC LIMIT 1");
if ($rows = mysqli_fetch_array($result)) {    
    date_default_timezone_set("Asia/Jakarta");
    $datetime = date('i');
    $dateTimeOut = $rows['outdate'];
    $orderDate = $rows['orderdate'];

    if ($datetime < 40) {
        $date = $dateTimeOut - $datetime;
    } else if ($orderDate > 39) {
        $date = $dateTimeOut - $datetime + 60;
    }


    $args = 1;

    if ($date < 1) {
        mysqli_query($mysql, "DELETE FROM turtor WHERE id='$rows[id]' and status_order='terselesaikan'");
    }
}

$result = $mysql->query("SELECT * FROM turtor WHERE status_order='berlangsung' ORDER BY id ASC LIMIT 1");
if ($rows = mysqli_fetch_array($result)) {
    date_default_timezone_set("Asia/Jakarta");
    $datetime = date('i');
    $dateTimeOut = $rows['outdate'];
    $orderDate = $rows['orderdate'];

    if ($datetime < 40) {
        $date = $dateTimeOut - $datetime;
    } else if ($orderDate > 39) {
        $date = $dateTimeOut - $datetime + 60;
    }

    $args = 1;

    if ($date < 1) {
        mysqli_query($mysql, "INSERT INTO orderterpakai SET user_order='$rows[user_order]', nomor='$rows[nomor]', nama_aplikasi='$rows[nama_aplikasi]', datetime='$rows[datetime]', harga='$rows[harga]', saldo_user='$rows[saldo_user]'");
        mysqli_query($mysql, "DELETE FROM turtor WHERE id='$rows[id]' and status_order='berlangsung'");
        mysqli_query($mysql, "UPDATE stocknomor SET status_order='kosong', nama_aplikasi='', user_order='' WHERE nomor='$rows[nomor]' and status_order='diorder' and user_order='$rows[user_order]'");
    }
}
?>