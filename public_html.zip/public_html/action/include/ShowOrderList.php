<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');

$auth = array(
    'username' => $_SESSION['username']
);

$result = $mysql->query("SELECT * FROM turtor WHERE user_order='$auth[username]' and status_order='berlangsung' ORDER BY id DESC");

while ($rows = mysqli_fetch_array($result)) {
    date_default_timezone_set("Asia/Jakarta");
    $datetime = date('i');
    $dateTimeOut = $rows['outdate'];
    $orderDate = $rows['orderdate'];

    if ($datetime < 40) {
        $date = $dateTimeOut - $datetime;
    } else if ($orderDate > 39) {
        $date = $dateTimeOut - $datetime + 60;
    }
    

    echo '
    <tr>
        <td style="width: 30%">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="margin: auto; background: none; display: block; shape-rendering: auto;" width="30px" height="30px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                <circle cx="50" cy="50" r="32" stroke-width="15" stroke="#442dff" stroke-dasharray="50.26548245743669 50.26548245743669" fill="none" stroke-linecap="round">
                    <animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" dur="1s" keyTimes="0;1" values="0 50 50;360 50 50"></animateTransform>
                </circle>
            </svg>
            <div class="text-center">Menunggu Pesan</div>
        </td>
        <td>
            <div class="row-succes-order">
            <span style="text-decoration: none; color: #666; font-size: small">
                <span id="num'.$rows['id'].'">'.$rows['nomor'].'</span>&nbsp; 
                    <i onclick="copyToClipboard('; echo "'#num".$rows['id']."'"; echo ')" class="bx bxs-copy" style="color: #442dff; font-size: 15px; cursor: pointer"></i> - 
                <span style="text-transform: uppercase;">'.$rows['nama_aplikasi'].'</span>
            </span>
            <br>
            <div class="timeEnd" style="margin-top: 5px">
                <span style="font-size: small; color: #666"><i class="bx bxs-time"></i> '.$date.' Menit Tersisa</span>
            </div>
            <br>
            <div class="box-shadow" style="width: max-content">
                <a id="cancel'.$rows['id'].'" style="cursor: pointer">
                    <button class="btn-order">
                        <span class="res" style="background: red; font-size: 11px; padding: 3px">Batalkan Order</span>
                    </button>
                </a>
            </div>
            </div>
        </td>
    </tr>';
            echo '
            <script>
                $("#cancel'.$rows['id'].'").click(function() {
                    var UrlCancel = "/action/cancel/order/id/'.$rows['id'].'";
                    $.ajax({
                        type: "GET",
                        url: UrlCancel,
                        success: function(response) {
                            if (response == 1) {
                                console.clear();
                                clearAll(window);
                                $("#list-order").load("/action/show/order/list");
                                $("#saldo-user").load("/action/show/user/saldo");
                                $.toast({
                                    text: "Order Berhasil Dibatalkan !!",
                                    showHideTransition: "slide",
                                    icon: "info",
                                    position: "top-left",
                                    hideAfter: "3000"
                                })
                            } else if (response == 0) {
                                clearAll(window);
                                $("#saldo-user").load("/action/show/user/saldo");
                                $("#list-order").load("/action/show/order/list");
                                $.toast({
                                    text: "Gagal Membatalkan Orderan !!",
                                    showHideTransition: "slide",
                                    icon: "info",
                                    position: "top-left",
                                    hideAfter: "3000"
                                })
                            }
                        }
                    });
                })
            </script>';
}

$result = $mysql->query("SELECT * FROM turtor WHERE user_order='$auth[username]' and status_order='terselesaikan' ORDER BY id DESC");

while ($rows = mysqli_fetch_array($result)) {
    date_default_timezone_set("Asia/Jakarta");
    $datetime = date('i');
    $dateTimeOut = $rows['outdate'];
    $orderDate = $rows['orderdate'];

    if ($datetime < 40) {
        $date = $dateTimeOut - $datetime;
    } else if ($orderDate > 39) {
        $date = $dateTimeOut - $datetime + 60;
    }

        $notWait = array('1' => '1');
        echo '
        <tr>
            <td class="row-td-sms">
                <div style="display: flex; flex-direction: column; box-shadow: rgba(0, 0, 0, 0.25) 0px 0.0625em 0.0625em, rgba(0, 0, 0, 0.25) 0px 0.125em 0.5em, rgba(255, 255, 255, 0.1) 0px 0px 0px 1px inset; margin: 5px; border-radius: 5px">';
        if (isset($notWait[$rows['refresh']])) {
            echo '
            <a id="resend'.$rows['id'].'" style="width: max-content; cursor: pointer; margin-bottom: 5px">
                <button class="btn-order" style="width: max-content">
                    <span class="res" style="font-size: 11px; padding: 3px">Resend SMS</span>
                </button>
            </a>';
            echo '
            <script>
                $("#resend'.$rows['id'].'").click(function() {
                    var UrlResend = "/action/resend/order/id/'.$rows['id'].'";
                    $.ajax({
                        type: "GET",
                        url: UrlResend,
                        success: function(response) {
                            if (response == 1) {
                                console.clear();
                                clearAll(window);
                                $("#list-order").load("/action/show/order/list");
                                $.toast({
                                    text: "Menunggu SMS!",
                                    showHideTransition: "slide",
                                    icon: "info",
                                    position: "top-left",
                                    hideAfter: "3000"
                                })
                            } else if (response == 0) {
                                clearAll(window);
                                $("#list-order").load("/action/show/order/list");
                                $.toast({
                                    text: "Gagal Resend SMS!!",
                                    showHideTransition: "slide",
                                    icon: "info",
                                    position: "top-left",
                                    hideAfter: "3000"
                                })
                            }
                        }
                    });
                })
            </script>
            ';
        }
        $Wait = array('0' => '0');
        if (isset($Wait[$rows['refresh']])) {
            echo '
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="padding-top: 15px; margin: auto; background: none; display: block; shape-rendering: auto;" width="30px" height="30px" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid">
                <circle cx="50" cy="50" r="32" stroke-width="15" stroke="#442dff" stroke-dasharray="50.26548245743669 50.26548245743669" fill="none" stroke-linecap="round">
                    <animateTransform attributeName="transform" type="rotate" repeatCount="indefinite" dur="1s" keyTimes="0;1" values="0 50 50;360 50 50"></animateTransform>
                </circle>
            </svg>
            <div class="text-center">Menunggu Pesan</div>';
        }
            echo '
                    <div style="color: #444; padding: 5px">
                        <span style="padding: 5px; border-radius: 5px;">'.$rows['sms'].'</span>
                    </div> 
                </div>
            </td>
            <td>
                <div class="row-succes-order">
                    <span style="text-decoration: none; color: #666; font-size: small">
                        <span id="num'.$rows['id'].'">'.$rows['nomor'].'</span>
                            <i onclick="copyToClipboard('; echo "'#num".$rows['id']."'"; echo ')" class="bx bxs-copy" style="color: #442dff; font-size: 15px; cursor: pointer"></i> - 
                        <span style="text-transform: uppercase;">'.$rows['nama_aplikasi'].'</span>
                    </span><br>
                    <div class="timeEnd" style="margin-top: 5px">
                        <span style="font-size: small; color: #666"><i class="bx bxs-time"></i> '.$date.' Menit Tersisa</span>
                    </div><br>
                    <div class="finish-order">
                        <a id="finish'.$rows['id'].'" class="box-shadow" style="cursor: pointer">
                            <button class="btn-order" style="width: max-content">
                                <span class="res" style="background: green; opacity: 0.8; font-size: 11px; padding: 3px">Selesaikan Order</span>
                            </button>
                        </a>
                    </div>
                </div>
            </td>
        </tr>';
            echo '
            <script>
                $("#finish'.$rows['id'].'").click(function() {
                    var UrlFinish = "/action/finish/order/id/'.$rows['id'].'";
                    $.ajax({
                        type: "GET",
                        url: UrlFinish,
                        success: function(response) {
                            if (response == 1) {
                                console.clear();
                                clearAll(window);
                                $("#list-order").load("/action/show/order/list");
                                $.toast({
                                    text: "Order Diselesaikan!",
                                    showHideTransition: "slide",
                                    icon: "info",
                                    position: "top-left",
                                    hideAfter: "3000"
                                })
                            } else if (response == 0) {
                                clearAll(window);
                                $("#list-order").load("/action/show/order/list");
                                $.toast({
                                    text: "Gagal Menyelesaikan Order!",
                                    showHideTransition: "slide",
                                    icon: "info",
                                    position: "top-left",
                                    hideAfter: "3000"
                                })
                            }
                        }
                    });
                })
            </script>';
}

$result = $mysql->query("SELECT * FROM turtor WHERE user_order='$auth[username]'");
if (mysqli_fetch_array($result)) {
} else {
    echo '
    <tr style="height: 60px">
        <td style="border-right: none ; text-align: center; color: #777; width: 90%">Orderan Kosong</td>
        <td style="border-left: none;  "></td>
    </tr>';
}

$result = $mysql->query("SELECT * FROM turtor WHERE user_order='$auth[username]' and refresh='0'");
while ($rows = mysqli_fetch_array($result)) {
    echo '
    <script>
    stateLoad'.$rows['id'].'();
    function stateLoad'.$rows['id'].' () {
        var urlSMS = "/action/check-update-order/id/'.$rows['id'].'";
        $.ajax({
            type: "GET",
            url: urlSMS,
            success: function (response) {
                if (response == 1) {
                    console.clear();
                    $("#list-order").load("/action/show/order/list");
                    var newSMS = new Audio("/assets/audio/sms.mp3");
                    $.toast({
                        text: "Anda punya SMS baru! !!",
                        showHideTransition: "slide",
                        icon: "info",
                        position: "top-left",
                        hideAfter: "3000"
                    })
                    newSMS.play();
                    clearTimeout(stateLoad'.$rows['id'].');
                } else if (response == 3) {
                    console.clear();
                    clearTimeout(stateLoad'.$rows['id'].');
                } else if (response == 0) {
                    setTimeout(stateLoad'.$rows['id'].', 2000);
                }
                console.log(response);
            }
        });
    }
    </script>';
}
?>