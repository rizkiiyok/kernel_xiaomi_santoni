<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');

$db = $mysql;
$args = array(
    'username' => $_SESSION['username'],
    'orderId' => $_GET['cekUpdateorderId']
);
$result = $db->query("SELECT * FROM turtor WHERE user_order='$args[username]' and id='$args[orderId]' and refresh='1' LIMIT 1");
$result1 = $db->query("SELECT * FROM turtor WHERE user_order='$args[username]' and id='$args[orderId]' and refresh='3' LIMIT 1");

if ($rows = mysqli_fetch_array($result)) {
    echo $rows['refresh'];
    $_SESSION['newSMS'] = array('time' => time());
    mysqli_query("UPDATE turtor SET refresh='3' WHERE user_order='$rows[user_order]' and id='$rows[id]' and nomor='$rows[nomor]'");
} else if ($rows = mysqli_fetch_array($result1)) {
    echo $rows['refresh'];
} else {
    echo 0;
}
?>