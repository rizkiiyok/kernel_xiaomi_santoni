<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');
if (empty($_SESSION['admin_active'])) { header("Location: /"); }

$args = array('depoId' => $_GET['confirmDepoId']);

$result = $mysql->query("SELECT * FROM depo WHERE id='$args[depoId]' and status='UNPAID' and via='Manual' LIMIT 1");
if ($rows = mysqli_fetch_array($result)) {
    $username = $rows['username'];
    $email = $rows['email'];
    $amount = $rows['amount'];

    $result = $mysql->query("SELECT * FROM rsusers12 WHERE username='$username' and email='$email' LIMIT 1");
    $rowsSaldo = mysqli_fetch_array($result);
    $saldoUser = $rowsSaldo['saldo_user'];

    $totalSaldo = $amount + $saldoUser;
    mysqli_query($mysql, "UPDATE rsusers12 SET saldo_user='$totalSaldo' WHERE username='$username' and email='$email'");
    mysqli_query($mysql, "UPDATE depo SET status='SELESAI' WHERE status='UNPAID' and username='$username' and email='$email'");
    header("Location: /iyok/deposit");
}
?>