<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');

    $requestPost = array(
        'username' => $_SESSION['username'],
        'aplikasi' => $_POST['aplikasi']
    );

    mysqli_query($mysql, "UPDATE rsusers12 SET lastorder='$requestPost[aplikasi]' WHERE username='$requestPost[username]'");

    $resultCekMax = $mysql->query("SELECT * FROM turtor WHERE user_order='$requestPost[username]' and status_order='berlangsung'");
    $no = 0;
    while (mysqli_fetch_array($resultCekMax)) {
        $no++;
    }
    $args = array('2' => '2');

    if (isset($args[$no])) {
        echo 2;
    } else {
        $resultcekSaldo = $mysql->query("SELECT * FROM rsusers12 WHERE username='$requestPost[username]' LIMIT 1");
        $resultHargaApp = $mysql->query("SELECT * FROM aplikasi WHERE value='$requestPost[aplikasi]' LIMIT 1");
    
        if ($rowsSaldo = mysqli_fetch_array($resultcekSaldo)) {
            $mySaldo = $rowsSaldo['saldo_user'];
        }
    
        if ($rowsHargaApp = mysqli_fetch_array($resultHargaApp)) {
            $hargaAsli = $rowsHargaApp['harga'];
            $hargaApp = $rowsHargaApp['harga'] - 1;
            $otp = $rowsHargaApp['otp'];
    
            if ($mySaldo > $hargaApp) {
                $hasilCekOrder = $mysql->query("SELECT * FROM stocknomor WHERE status_order='kosong' and app_use NOT LIKE '%$requestPost[aplikasi]%' LIMIT 1");

                if ($rows = mysqli_fetch_array($hasilCekOrder)) {

                    mysqli_query($mysql, "UPDATE stocknomor SET status_order='berlangsung', nama_aplikasi='$requestPost[aplikasi]', user_order='$requestPost[username]' WHERE nomor='$rows[nomor]' and status_order='kosong'");

                    $result = $mysql->query("SELECT * FROM stocknomor WHERE user_order='$requestPost[username]' and nama_aplikasi='$requestPost[aplikasi]' and status_order='berlangsung' LIMIT 1");

                    if ($rows = mysqli_fetch_array($result)) {
                        $nomorOrder = $rows['nomor'];
                        mysqli_query($mysql, "INSERT INTO stocknomor SET status_order='diorder', user_order='$rows[user_order]', nomor='$nomorOrder', app_use='$rows[app_use]', nama_aplikasi='$rows[nama_aplikasi]', phone='$rows[phone]'");
                        mysqli_query($mysql, "DELETE FROM stocknomor WHERE status_order='berlangsung' and user_order='$requestPost[username]' and nama_aplikasi='$requestPost[aplikasi]' and nomor='$nomorOrder'");
                    }

                    $result = $mysql->query("SELECT * FROM stocknomor WHERE user_order='$requestPost[username]' and nama_aplikasi='$requestPost[aplikasi]' and status_order='diorder' and nomor='$nomorOrder' LIMIT 1");

                    if ($rows = mysqli_fetch_array($result)) {
                        $resultcekSaldo = $mysql->query("SELECT * FROM rsusers12 WHERE username='$requestPost[username]'");

                        if ($rowsSaldo = mysqli_fetch_array($resultcekSaldo)) {
                            $saldoUser = number_format($rowsSaldo['saldo_user'],0,',','.');
                            $mySaldo = $rowsSaldo['saldo_user'];
                        }
                        $saldoSekarang = $mySaldo - $hargaAsli;
                        date_default_timezone_set("Asia/Jakarta");
                        $waktuSekarang = date('YmdHi');
                        $outDate = date('i', strtotime("+20 minutes"));
                        $orderDate = date('i');
                        $dateTime = date('Y-m-d H:i');
                        mysqli_query($mysql, "INSERT INTO turtor SET nomor='$rows[nomor]', nama_aplikasi='$requestPost[aplikasi]', user_order='$requestPost[username]', status_order='berlangsung', harga='$hargaAsli', orderdate='$orderDate', datetime='$dateTime', refresh='0', otp='$otp', outdate='$outDate', phone='$rows[phone]', saldo_user='$saldoUser'");
                        mysqli_query($mysql, "UPDATE rsusers12 SET saldo_user='$saldoSekarang' WHERE username='$requestPost[username]'");
                        echo 1;
                    } else {
                        echo 3;
                    }
                } else {
                    echo 4;
                }

            } else {
                echo 5;
            }
        } else {
            echo 6;
        }
    }
?>