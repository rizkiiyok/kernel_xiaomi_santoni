<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');

$db = $mysql;
$args = array(
    'username' => $_SESSION['username'],
    'orderId' => $_GET['cancelId']
);
$result = $db->query("SELECT * FROM turtor WHERE user_order='$args[username]' and status_order='berlangsung' and id='$args[orderId]' LIMIT 1");

if ($rows = mysqli_fetch_array($result)) {
    $resultcekSaldo = $mysql->query("SELECT * FROM rsusers12 WHERE username='$args[username]'");
    if ($rowsSaldo = mysqli_fetch_array($resultcekSaldo)) {
        $mySaldo = $rowsSaldo['saldo_user'];
    }
    $saldoSekarang = $mySaldo + $rows['harga'];

    $result = $mysql->query("SELECT * FROM stocknomor WHERE nomor='$rows[nomor]' and user_order='$args[username]' and nama_aplikasi='$rows[nama_aplikasi]' LIMIT 1");
    if ($rowsStockNomor = mysqli_fetch_array($result)) {
        mysqli_query($mysql, "INSERT INTO stocknomor SET status_order='kosong', nomor='$rowsStockNomor[nomor]', app_use='$rowsStockNomor[app_use]', phone='$rowsStockNomor[phone]'");
    }

    mysqli_query($mysql, "DELETE FROM stocknomor WHERE nomor='$rows[nomor]' and user_order='$args[username]' and nama_aplikasi='$rows[nama_aplikasi]'");
    mysqli_query($mysql, "DELETE FROM turtor WHERE user_order='$args[username]' and status_order='berlangsung' and id='$args[orderId]'");
    mysqli_query($mysql, "UPDATE rsusers12 SET saldo_user='$saldoSekarang' WHERE username='$args[username]'");
    echo 1;
} else {
     echo 0;
}
?>