<?php
include '../DBaseLoad.php';

if (empty($_SESSION['user_login_true'])) {
    header("Location: /");
} else if (!empty($_SESSION['user_login_true'])) {
    if (isset($_GET['resendId'])) {
        include 'include/RequestResend.php';
    } else if (isset($_GET['cekUpdateorderId'])) {
        include 'include/CekUpdateOrder.php';
    } else if (isset($_GET['finishId'])) {
        include 'include/FinishOrder.php';
    } else if (isset($_GET['cancelId'])) {
        include 'include/CancelOrder.php';
    } else if (isset($_GET['stateload'])) {
        include 'include/StateLoad.php';
    } else if (isset($_GET['phoneId'])) {
        include 'include/DeletePhone.php';
    } else if (isset($_GET['cancelDepoId'])) {
        include 'include/CancelDeposit.php';
    } else if (isset($_GET['confirmDepoId'])) {
        include 'include/ConfirmDeposit.php';
    } else if (isset($_GET['createOrderReq'])) {
        include 'include/CreateOrder.php';
    } else if (isset($_GET['ShowOrderList'])) {
        include 'include/ShowOrderList.php';
    } else if (isset($_GET['ShowUserSaldo'])) {
    include 'include/ShowSaldo.php';
    } else {
    echo '404%ERROR%FOUND';
    }
}
?>