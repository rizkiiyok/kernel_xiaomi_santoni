<?php
session_start();
ob_start();

$args = array('dbase' => mysqli_connect("localhost", "hanp1571_wp904", "memek92138u124@(2", "hanp1571_wp904"));
$mysql = $args['dbase'];
define('HanyaOTP.com',true);

$resultCookie = $mysql->query("SELECT cookieLogin FROM rsusers12 WHERE username='$_COOKIE[username]' and email='$_COOKIE[email]'");
if ($rowsCookie = mysqli_fetch_array($resultCookie)){
    $cookie = $rowsCookie['cookieLogin'];   
}

if (isset($_COOKIE[$cookie])) {
    
    $args = array('ryue' => 'ryue');
    
    $user_login_true = $_COOKIE['user_login_true'];
    $username = $_COOKIE['username'];
    $email = $_COOKIE['email'];

    if (isset($args[$username])) {
        $_SESSION['admin_active'] = true;
    }
    $_SESSION['user_login_true'] = $user_login_true;
    $_SESSION['username'] = $username;
    $_SESSION['email'] = $email;
    
    $result = $mysql->query("SELECT * FROM rsusers12 WHERE username='$username' and email='$email' LIMIT 1");
    if (mysqli_fetch_array($result)) {
        //
    } else {
        header("Location: /keluar");
    }
} else {
    
    $user_login_true = $_COOKIE['user_login_true'];
    $username = $_COOKIE['username'];
    $email = $_COOKIE['email'];
            
    setcookie("user_login_true", $user_login_true, time() - 604800);
    setcookie("username", "$username", time() - 604800);
    setcookie("email", "$email", time() - 604800);
    session_unset();
    session_destroy();
}
?>