<?php
require '../DBaseLoad.php';

if (isset($_GET['tripay'])) {
    include 'include/Tripay.php';
} else if (isset($_GET['hp'])) {
    include 'include/hp.php';
} else {
    echo '404%ERROR%FOUND';
}
?>