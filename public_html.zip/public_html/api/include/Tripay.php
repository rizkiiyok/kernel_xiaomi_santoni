<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');

$db = $args['dbase'];

$json = file_get_contents('php://input');

$callbackSignature = isset($_SERVER['HTTP_X_CALLBACK_SIGNATURE'])
    ? $_SERVER['HTTP_X_CALLBACK_SIGNATURE']
    : '';

$privateKey = '0PDoh-lpZMb-rDflq-wJzQs-5UZ6S';

$signature = hash_hmac('sha256', $json, $privateKey);

if ($callbackSignature !== $signature) {
    exit(json_encode([
        'success' => false,
        'message' => 'Invalid signature',
    ]));
}

$data = json_decode($json);

if (JSON_ERROR_NONE !== json_last_error()) {
    exit(json_encode([
        'success' => false,
        'message' => 'Invalid data sent by payment gateway',
    ]));
}

if ('payment_status' !== $_SERVER['HTTP_X_CALLBACK_EVENT']) {
    exit(json_encode([
        'success' => false,
        'message' => 'Unrecognized callback event: ' . $_SERVER['HTTP_X_CALLBACK_EVENT'],
    ]));
}

$uniqueRef = $db->real_escape_string($data->merchant_ref);
$status = strtoupper((string) $data->status);

if ($data->is_closed_payment === 1) {
    $result = $db->query("SELECT * FROM depo WHERE kodeunik = '{$uniqueRef}' AND status = 'UNPAID' LIMIT 1");

    if (! $result) {
        exit(json_encode([
            'success' => false,
            'message' => 'Invoice not found or already paid: ' . $uniqueRef,
        ]));
        echo 'yess';
    }

    while ($invoice = $result->fetch_object()) {
        switch ($status) {
            case 'PAID':
                if (! $db->query("UPDATE depo SET status = 'PAID' WHERE kodeunik = '{$uniqueRef}'")) {
                    exit(json_encode([
                        'success' => false,
                        'message' => $db->error,
                    ]));
                }
                $result = $db->query("SELECT * FROM depo WHERE kodeunik='{$uniqueRef}' and STATUS='PAID'");
                if ($rows = mysqli_fetch_array($result)) {
                    $amount = $rows['amount'];
                    $username = $rows['username'];
                    $kodeunik = $data->merchant_ref;
                    $result = $db->query("SELECT * FROM rsusers12 WHERE username='$username'");
                    if ($rows = mysqli_fetch_array($result)) {
                        $saldo = $amount + $rows['saldo_user'];
                        $totalDeposit = $amount + $rows['total_deposit'];
                        if (! $db->query("UPDATE rsusers12 SET saldo_user='$saldo', total_deposit='$totalDeposit' WHERE username='$username'")) {
                            echo 'SUKSES MENAMBAH SALDO';
                        }
                        if (! $db->query("UPDATE depo SET status='SELESAI' WHERE kodeunik='$kodeunik'")) {
                            echo 'SUKSES TRANSAKSI';
                        }
                    }
                }
                break;

            default:
                exit(json_encode([
                    'success' => false,
                    'message' => 'Unrecognized payment status',
                ]));
        }

        exit(json_encode(['success' => true]));
    }
}
?>