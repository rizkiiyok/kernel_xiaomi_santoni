<?php
if (!defined('HanyaOTP.com')) die ('HanyaOTP.com');

$args = array(
    'sms' => filter_input(INPUT_POST, 'text', FILTER_SANITIZE_SPECIAL_CHARS),
    'no' => $_GET['no'],
    'hp' => $_GET['hp'],
    'otpName' => $_POST['phone'],
);

mysqli_query($mysql, "INSERT INTO semuasms SET nomor='$args[no]', sms='$args[sms]', otp='$args[otpName]'");

$result = $mysql->query("SELECT * FROM stocknomor WHERE nomor='$args[no]' and phone='$args[hp]'");

if ($rows = mysqli_fetch_array($result)) {
    $result = $mysql->query("SELECT * FROM turtor WHERE nomor='$args[no]' and status_order='berlangsung' and otp LIKE '%$args[otpName]%'");

    if ($rows = mysqli_fetch_array($result)) {
        
        $hargaApp = $rows['harga'];
        $resultUser = $mysql->query("SELECT * FROM rsusers12 WHERE username='$rows[user_order]' LIMIT 1");
        if ($rowsUser = mysqli_fetch_array($resultUser)) {
            $totalOrder = $hargaApp + $rowsUser['total_order'];
            mysqli_query($mysql, "UPDATE rsusers12 SET total_order='$totalOrder' WHERE username='$rowsUser[username]' and email='$rowsUser[email]'");
        } else {
            echo 'Failed';
        }
        
        $userOrder = $rows['user_order'];
        $appUse = $rows['nama_aplikasi'];
        $sms = ('
        <div style="padding: 3px; margin: 4px">
            <button class="accordion" style="display: flex; justify-content: space-between">
                SMS<span style="font-size: 20px; font-weight: bold; color: #666" class="bx bx-chevron-down"></span>    
            </button>
            <div id="panelsms" class="panel">
                <p>'.$args['sms'].'</p>
            </div>
        </div>  
        ');

        $result = $mysql->query("SELECT * FROM nomorappterpakai WHERE nomor='$args[no]' LIMIT 1");

        if ($rowsHistoryNomor = mysqli_fetch_array($result)) {
            mysqli_query($mysql, "UPDATE nomorappterpakai SET app_use='$rowsHistoryNomor[app_use]$appUse,' WHERE nomor='$args[no]'");

        } else {
            mysqli_query($mysql, "INSERT INTO nomorappterpakai SET nomor='$args[no]', app_use='$appUse,'");
        }

        $result = $mysql->query("SELECT app_use FROM nomorappterpakai WHERE nomor='$args[no]' LIMIT 1");
        $rowsAppuse = mysqli_fetch_array($result);
        mysqli_query($mysql, "UPDATE stocknomor SET status_order='kosong', app_use='$rowsAppuse[app_use]', nama_aplikasi='', user_order='' WHERE nomor='$args[no]' and phone='$args[hp]' and status_order='diorder'");

        mysqli_query($mysql, "INSERT INTO orderterpakai SET nomor='$rows[nomor]', nama_aplikasi='$rows[nama_aplikasi]', user_order='$userOrder', sms='$sms', harga='$rows[harga]', datetime='$rows[datetime]', saldo_user='$rows[saldo_user]'");
        mysqli_query($mysql, "UPDATE turtor SET sms='$args[sms]', status_order='terselesaikan', refresh='1' WHERE user_order='$userOrder' and status_order='berlangsung' and nomor='$args[no]' and otp LIKE '%$args[otpName]%' LIMIT 1");

        echo 'Sukses Mengirim SMS!';
    } else {
        $sms = ('
        <div style="padding: 3px; margin: 4px">
            <button class="accordion" style="display: flex; justify-content: space-between">
                SMS<span style="font-size: 20px; font-weight: bold; color: #666" class="bx bx-chevron-down"></span>    
            </button>
            <div class="panel">
                <p>'.$args['sms'].'</p>
            </div>
        </div>  
        ');
        $result = $mysql->query("SELECT * FROM turtor WHERE status_order='terselesaikan' and nomor='$args[no]' and otp LIKE '%$args[otpName]%'");
    
        if ($rows = mysqli_fetch_array($result)) {
            $result = $mysql->query("SELECT sms FROM orderterpakai WHERE nomor='$args[no]' and user_order='$rows[user_order]' and nama_aplikasi='$rows[nama_aplikasi]'");
            $rowSMS = mysqli_fetch_array($result);
            

            mysqli_query($mysql, "UPDATE turtor SET sms='$args[sms]', refresh='1' WHERE nomor='$args[no]' and status_order='terselesaikan' and otp LIKE '%$args[otpName]%'");
            mysqli_query($mysql, "UPDATE orderterpakai SET sms='$sms$rowSMS[sms]' WHERE nomor='$args[no]' and user_order='$rows[user_order]' and nama_aplikasi='$rows[nama_aplikasi]'");
            echo 'Sukses Resend SMS!';
        }
    }
} else {
    $result = $mysql->query("SELECT * FROM nomorappterpakai WHERE nomor='$args[no]' LIMIT 1");

    if ($rows = mysqli_fetch_array($result)) {
        mysqli_query($mysql, "DELETE FROM stocknomor WHERE phone='$args[hp]'");
        mysqli_query($mysql, "INSERT INTO stocknomor SET nomor='$args[no]', status_order='kosong', phone='$args[hp]', app_use='$rows[app_use]'");
        echo 'Sukses Mengganti Nomor!';
    } else {
        mysqli_query($mysql, "DELETE FROM stocknomor WHERE phone='$args[hp]'");
        mysqli_query($mysql, "INSERT INTO stocknomor SET nomor='$args[no]', status_order='kosong', phone='$args[hp]'");
        echo 'Sukses Mengganti Nomor!';
    }
}
?>